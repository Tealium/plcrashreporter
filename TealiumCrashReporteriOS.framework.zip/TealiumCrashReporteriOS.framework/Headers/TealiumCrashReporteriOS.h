//
//  TealiumCrashReporteriOS.h
//  TealiumCrashReporteriOS
//
//  Created by Jonathan Wong on 2/27/18.
//

//! Project version number for TealiumCrashReporteriOS.
FOUNDATION_EXPORT double TealiumCrashReporteriOSVersionNumber;

//! Project version string for TealiumCrashReporteriOS.
FOUNDATION_EXPORT const unsigned char TealiumCrashReporteriOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TealiumCrashReporteriOS/PublicHeader.h>

#import "CrashReporter.h"

